﻿using System.Windows;
using ZavodOnline.Client.ViewModels;

namespace ZavodOnline.Client
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();

            var vm = new LoginViewModel();
            vm.LoginSucceeded += OnLoginSucceeded;

            DataContext = vm;
        }

        private void OnLoginSucceeded()
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }
    }
}
